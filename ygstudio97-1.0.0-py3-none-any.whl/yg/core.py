import os
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, scrolledtext
import subprocess
import webbrowser
import http.server
import socketserver
import threading
import math

def show_wlc():
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo("YGstudio97", "Thanks for download!\nIt's hosted on YGstudio97.\n\nfor more info, visit:\nhttps://github.com/YGstudio97\n\n@YGstudio97 - Yusuf")
    print("visit: https://github.com/YGstudio97")
    root.destroy()

def create(target_type, name):
    if target_type == "file":
        open(name, 'w').close()
        print(f"✅ File '{name}' created.")
    elif target_type == "folder":
        os.makedirs(name, exist_ok=True)
        print(f"✅ Folder '{name}' created.")
    else:
        print("❌ Invalid type. Use 'file' or 'folder'.")

def addlogo(image_path):
    print("⚠️ Logo upload placeholder. (Manual icon change required)")

def surname(new_name):
    if 1 <= len(new_name) <= 5:
        print(f"📛 Surname (rename logic) set to: {new_name}")
    else:
        print("❌ Name must be 1–5 characters.")

def help():
    funcs = [
        "show_wlc()",
        "create('file' or 'folder', name)",
        "addlogo(image_path)",
        "surname(name)",
        "poptext(message)",
        "edite(file_path)",
        "delet(file_path)",
        "open_app()",
        "get(prompt='Enter value')",
        "python(code)",
        "api(type, url)",
        "html(code)", "js(code)", "css(code)",
        "c(code)", "csharp(code)", "java(code)",
        "dirt(path)",
        "math(expr)",
        "host(port=8000)",
        "yg()",
    ]
    print("📘 YGstudio97 Functions:\n" + "\n".join(funcs))

def poptext(message):
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo("YGstudio97", message)
    root.destroy()

def edite(file_path):
    def save():
        with open(file_path, "w") as f:
            f.write(text.get("1.0", tk.END))
        poptext(f"Saved: {file_path}")
        editor.destroy()

    editor = tk.Tk()
    editor.title(file_path)
    editor.geometry("600x400")

    text = scrolledtext.ScrolledText(editor)
    text.pack(fill="both", expand=True)

    if os.path.exists(file_path):
        with open(file_path) as f:
            text.insert("1.0", f.read())

    tk.Button(editor, text="Save", command=save).pack()
    editor.mainloop()

def delet(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"🗑 Deleted: {file_path}")
    else:
        print("❌ File not found")

def open_app():
    root = tk.Tk()
    root.withdraw()
    
    # Ask user to select any executable file
    file_path = filedialog.askopenfilename(
        title="Select an application to open",
        filetypes=[("Executable files", "*.exe;*.bat;*.cmd;*.com"), ("All files", "*.*")]
    )
    
    if file_path and os.path.isfile(file_path):
        try:
            subprocess.Popen([file_path])
            messagebox.showinfo("Open App", f"Opening {os.path.basename(file_path)}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open app:\n{e}")
    else:
        messagebox.showwarning("Open App", "No file selected or file does not exist.")
    
    root.destroy()

def get(prompt="Enter something"):
    root = tk.Tk()
    root.withdraw()
    val = simpledialog.askstring("Input", prompt)
    root.destroy()
    return val

def python(code):
    try:
        exec(code)
    except Exception as e:
        print("Python Error:", e)

def api(type_, url):
    print(f"📡 API call to {url} as {type_} (not implemented)")

def html(code): web(code)
def js(code): web(f"<script>{code}</script>")
def css(code): web(f"<style>{code}</style>")
def c(code): print("C not implemented")
def csharp(code): print("C# not implemented")
def java(code): print("Java not implemented")

def dirt(path="."):
    try: print("\n".join(os.listdir(path)))
    except Exception as e: print("Error:", e)

def math(expr):
    try:
        result = eval(expr, {"__builtins__": None}, math.__dict__)
        print("🧮 Result:", result)
        return result
    except Exception as e:
        print("❌ Math Error:", e)

def host(port=8000):
    handler = http.server.SimpleHTTPRequestHandler
    httpd = socketserver.TCPServer(("", port), handler)
    print(f"🌐 Serving at http://localhost:{port}")
    threading.Thread(target=httpd.serve_forever, daemon=True).start()

def yg():
    with open("index.html", "w") as f:
        f.write("<html><body><h1>Hello World</h1></body></html>")
    webbrowser.open("index.html")

def web(content):
    with open("temp.html", "w", encoding="utf-8") as f:
        f.write(content)
    webbrowser.open("temp.html")
